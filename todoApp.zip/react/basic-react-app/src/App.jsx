import "./App.css";
import { useState } from "react";
import Todoinput from "./Todoinput.jsx";
import List from "./List.jsx";

function App() {
  // State to manage the list of todos
  const [listTodo, setListTodo] = useState([]);

  // Function to add todo item to the list
  const addList = (inputText) => {
    if(inputText.trim()) { // Check if inputText is not empty or just spaces
      setListTodo([...listTodo, inputText]);
    }
  };

  // Function to delete a todo item
  const deleteItem = (index) => {
    const updatedList = listTodo.filter((_, i) => i !== index);
    setListTodo(updatedList);
  };

  return (
    <div className="main-container">
      <div className="centercontainer">
        <h1>TODO APP</h1>
        <Todoinput addList={addList} />
        <h1 className="app-heading">Todo List</h1>
        <hr />
        <ul>
          {listTodo.map((listitem, index) => (
            <List key={index} item={listitem} deleteItem={() => deleteItem(index)} />
          ))}
        </ul>
      </div>
    </div>
  );
}

export default App;
