function Title(){
    return <h1>Hello Wolrd</h1>;
  }
function add(a,b)
{
    return a+b;
}
  export {Title,add};