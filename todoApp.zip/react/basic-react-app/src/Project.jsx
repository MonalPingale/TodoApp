import "./Project.css"
import Price from "./Price.jsx";
function Project({title,idx}){
 let odleprices=["1200","278","567","999"];
 let newprices=["270","200","400","500"]
 let desccription=[["James Goslin"," It Is most famous book"],
                  ["Dennies Ritche ","It is mother of all language books"],
                  ["Brenden Eich ","It is frontend Development book"],
                  ["Guido van rossum ","It is opened language"]]

        return (
        <div className="Project" >
          <h4>{title}</h4>
             <p>{desccription[idx][0]}</p>
             <p>{desccription[idx][1]}</p>
            <Price odlprice={odleprices[idx]} newprice={newprices[idx]} />                 
        </div>
        );
    
}

export default Project;