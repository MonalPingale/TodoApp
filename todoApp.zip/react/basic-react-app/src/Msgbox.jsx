function Msgbox({msg,textcolr})
{
    let back={color: textcolr};
    return (
     <div style={back}>
        <h1>Hello {msg}</h1>
     </div>
    );
}
export default Msgbox;