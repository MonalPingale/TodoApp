function List(props) {
    return (
      <li className="list-item">
        {props.item}
        <span className="icons" onClick={props.deleteItem}>
          <i className="fa-solid fa-trash"></i>
        </span>
      </li>
    );
  }
  
  export default List;
  