import Project from "./project.jsx";
import "./Producttab.css"

function Producttab()
{
    
    return(
        <div className="product">
            <h1>Book Your Favorite Book</h1><br />
            <Project title="Java Book" idx={0}/>
           <Project title="C book" idx={1}/>
            <Project title="javascript Book" idx={2}/>
            <Project title="Python Book" idx={3}/>
        </div>
     
    );
}

export default Producttab;