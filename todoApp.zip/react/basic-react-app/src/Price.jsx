export default function Price({odlprice,newprice}){
    let styles={
        textDecorationLine:"line-through",
    };
    let newstyles={
        fontWeight:"bold",
    }
    let divwhole={
        backgroundColor:"#e0c367",
        height:"40px",
        width:"250px",
        marginRight:"10px",
        borderBottomLeftRadius:"14px",
        borderBottomRightRadius:"14px",
        
    }
    return (
     <div style={divwhole}>
        <span style={styles}>{odlprice}</span>
        &nbsp;&nbsp;&nbsp;
        <span style={newstyles}>{newprice}</span>
     </div>
    );
}